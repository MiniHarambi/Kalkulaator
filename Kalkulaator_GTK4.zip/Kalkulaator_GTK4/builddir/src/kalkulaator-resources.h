#ifndef __RESOURCE_kalkulaator_H__
#define __RESOURCE_kalkulaator_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *kalkulaator_get_resource (void);
#endif
